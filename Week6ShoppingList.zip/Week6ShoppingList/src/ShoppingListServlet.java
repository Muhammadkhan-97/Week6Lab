import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("")
public class ShoppingListServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            System.out.println("In get start");

            // get username form session
            HttpSession session = request.getSession();
            String action = request.getParameter("action");

            // manage register and home page loading based on session
            String username = (String) session.getAttribute("username");
            if (username != null && action == null) {
                request.getRequestDispatcher("shoppingList.jsp").forward(request, response);
            }

            // if action is null resend the request with action
            else if (action == null) {
                request.setAttribute("action", "register");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }

            // load register
            else if (action.equals("register")) {
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }

            // load add items
            else if (action.equals("add")) {
                String item = request.getParameter("item");
                if (item == null || item.isEmpty()) {
                    request.setAttribute("error", "Invalid item details, please try again.");
                } else {
                    /*
                     * if itemList is already added in session then just add item in existing array
                     * if itemList not available in session, create a new array with item and save in session
                     */
                    ArrayList<String> itemList = (ArrayList<String>) session.getAttribute("itemList");
                    if (itemList == null) itemList = new ArrayList<>();
                    itemList.add(item);
                    session.setAttribute("itemList", itemList);
                }

                request.getRequestDispatcher("shoppingList.jsp").forward(request, response);
            }

            // load delete items
            else if (action.equals("delete")) {
                String item = request.getParameter("item");
                if (item == null || item.isEmpty()) {
                    request.setAttribute("error", "Before trying to delete, please select a item from list.");
                } else {
                    // delete item from session
                    ArrayList<String> itemList = (ArrayList<String>) session.getAttribute("itemList");
                    itemList.remove(item);
                }

                request.getRequestDispatcher("shoppingList.jsp").forward(request, response);
            }

            // logout action, remove user session data
            else if (action.equals("logout")) {
                request.setAttribute("error", "Logout Successful!");
                session.invalidate();
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // get username
        String username = request.getParameter("username");

        // if pass empty username
        if (username == null || username.trim().isEmpty()) {
            // Set an error message
            request.setAttribute("error", "Username name can't be empty!, Please try again");
            // Forward the request to the login page
            request.getRequestDispatcher("register.jsp").forward(request, response);
        } else {
            // get username form post request
            HttpSession session = request.getSession();
            // update username in session
            session.setAttribute("username", username);

            // load home view
            request.getRequestDispatcher("shoppingList.jsp").forward(request, response);
        }
    }

}
